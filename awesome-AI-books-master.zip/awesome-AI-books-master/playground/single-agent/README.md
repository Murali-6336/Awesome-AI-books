# Single-Agent Playground

All tasks in this folder will show you how single agent works.