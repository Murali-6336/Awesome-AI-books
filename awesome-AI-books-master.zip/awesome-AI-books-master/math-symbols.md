# Mathematic Symbols

Some often used Mathematic symbols' check list :mortar_board:

## Numbers

Symbol | Meaning | Symbol | Meaning
------ | ------- | ------ | -------
ℝ | Real numbers (实数) | ℚ | Rational numbers (有理数)
ℤ | Integers (整数) | ℕ | Natural numbers (自然数)
ℂ | Complex number (复数) |

